import { StackNavigator } from 'react-navigation';
import StreamInfo from './components/StreamInfo';
import AutoComplete from './components/TagAutoComplete';
import LoginPage from './screen/LoginPage';
import Tutorial from './screen/Tutorial';
import Home from './screen/HomeTabNavigator';
import WatchLive from './screen/WatchLive';

export default StackNavigator({
  Login: {
    screen: LoginPage,
  },
  Tutorial: {
    screen: Tutorial,
  },
  Home: {
    screen: Home,
  },
  WatchLive: {
    screen: WatchLive,
  },
});
