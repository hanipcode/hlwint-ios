import login from './login';
import tutorial from './tutorial';
import card from './card';
import stream from './stream';
import streamInfo from './streamInfo';
import autocomplete from './autocomplete';
import button from './button';

export default {
  login,
  tutorial,
  card,
  stream,
  autocomplete,
  streamInfo,
  button,
};
