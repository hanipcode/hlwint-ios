export default {
  GRADIENTS_PROPS: {
    colors: ['#D81B60', '#E91E63', '#f44336'],
    lications: [0, 0.2, 1],
    start: { x: 1, y: 0 },
    end: { x: 0, y: 0 },
  },
};
