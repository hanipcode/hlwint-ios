export default {
  ACTIVITY: {
    LOGIN: 'UserLogin',
  },
};
