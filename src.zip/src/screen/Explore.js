import React from 'react';
import { View, Text } from 'react-native';

const Explore = () => (
  <View>
    <Text>Explore</Text>
  </View>
);

export default Explore;
